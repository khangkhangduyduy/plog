let list = document.getElementById('list');
let filter = document.querySelector('.filter');
let count = document.getElementById('count');
let storedCartItems = localStorage.getItem('cartItems');
let cartItems = storedCartItems ? JSON.parse(storedCartItems) : [];
let listProducts = [{
        id: 1,
        name: 'Name product white-black',
        price: 205600,
        quantity: 0,
        image: 'img1.jpg',
        nature: {
            color: ['white', 'black'],
            size: ['S', 'M', 'L'],
            type: 'T-shirt'
        }
    },
    {
        id: 2,
        name: 'Name product white-black-grey',
        price: 300000,
        quantiy: 30,
        image: 'img2.jpg',
        nature: {
            color: ['white', 'black', 'grey'],
            size: ['S', 'M', 'L'],
            type: 'Polo'
        }
    },
    {
        id: 3,
        name: 'Name product black',
        price: 200000,
        quantiy: 30,
        image: 'img3.jpg',
        nature: {
            color: ['black'],
            size: ['S', 'M', 'L'],
            type: 'T-shirt'
        }
    },
    {
        id: 4,
        name: 'Name product blue-black',
        price: 400000,
        quantiy: 30,
        image: 'img4.jpg',
        nature: {
            color: ['black', 'blue'],
            size: ['S', 'M', 'L'],
            type: 'T-shirt'
        }
    },
    {
        id: 5,
        name: 'Name product brown',
        price: 320000,
        quantiy: 30,
        image: 'img5.jpg',
        nature: {
            color: ['brown'],
            size: ['S', 'M', 'L'],
            type: 'Polo'
        }
    },
    {
        id: 6,
        name: 'Name product white-black',
        price: 100000,
        quantiy: 30,
        image: 'img6.jpg',
        nature: {
            color: ['white', 'black'],
            size: ['S', 'M', 'L'],
            type: 'Shirt'
        }
    },
    
];
let productFilter = listProducts;
showProduct(productFilter);

function showProduct(productFilter) {
    count.innerText = productFilter.length;
    list.innerHTML = '';
    productFilter.forEach(item => {
        let newItem = document.createElement('div');
        newItem.classList.add('item');

        // create image
        let newImage = new Image();
        newImage.src = item.image;
        newItem.appendChild(newImage);
        // create name product
        let newTitle = document.createElement('div');
        newTitle.classList.add('title');
        newTitle.innerText = item.name;
        newItem.appendChild(newTitle);
        // create price
        let newPrice = document.createElement('div');
        newPrice.classList.add('price');
        newPrice.innerText = item.price.toLocaleString() + ' đ';
        newItem.appendChild(newPrice);
        // create buttons
        let buttonsDiv = document.createElement('div');
        newPrice.classList.add('gell');
        let Btn = document.createElement('button');
        Btn.innerText = 'mua';
        Btn.addEventListener('click', function () {
            // Xử lý khi nút được nhấn
            addToCart(item); // Gọi hàm thêm vào giỏ hàng
            updateCartUI(); // Update the cart UI
        });
        function addToCart(item) {
            // Thêm item vào giỏ hàng
            cartItems.push({
                ...item,
                quantity: 1
            });
            updateTotalPrice(); // Update the total price
        }
        function addToCart(item) {
            // Kiểm tra xem sản phẩm đã tồn tại trong giỏ hàng chưa
            let existingItem = cartItems.find(cartItem => cartItem.id === item.id);
            if (existingItem) {
                // Nếu sản phẩm đã tồn tại, tăng số lượng
                existingItem.quantity += 1;
            } else {
                // Nếu sản phẩm chưa tồn tại, thêm vào giỏ hàng với số lượng là 1
                cartItems.push({
                    ...item,
                    quantity: 1
                });
            }
            updateTotalPrice(); // Update the total price
        }
        function updateCartUI() {
            // Giả sử bạn đã xác định cartItemsList ở đâu đó của code
            let cartItemsList = document.getElementById('cartItemsList');
            //Xóa các mục giỏ hàng hiện có
            cartItemsList.innerHTML = '';
            // Thêm từng mặt hàng vào giao diện giỏ hàng
            cartItems.forEach(function (cartItem, index) {
                let cartItemElement = document.createElement('div');
                cartItemElement.classList.add('cart-item');
                let itemColor = '';
        if (cartItem.nature && cartItem.nature.color) {
            itemColor = cartItem.nature.color.join(', '); 
        }
                // Hiển thị thông tin về mặt hàng
                cartItemElement.innerHTML = `
            <div style="padding:10px;">
            <img src="${cartItem.image}" alt="${cartItem.name}" style="width: 50px; height: 50px;">
            <div class="item-details">
                <span class="item-name">${cartItem.name}</span><br/>
                <span class="item-price">${cartItem.price} VND</span><br/>
                <span class="item-quantity">Số lượng: ${cartItem.quantity}</span><br/>
                
            </div>
            
            </div>
        `;
                cartItemsList.appendChild(cartItemElement);
            });
            // Thêm một nút để xóa tất cả các mục
            let deleteAllButton = document.createElement('button');
            deleteAllButton.innerText = 'Xóa tất cả';
            deleteAllButton.addEventListener('click', function () {
                deleteAllItems();
                updateCartUI(); // Cập nhật giao diện giỏ hàng sau khi xóa tất cả các mặt hàng
                updateTotalPrice(); // Cập nhật tổng giá sau khi xóa tất cả các mặt hàng
            });
            cartItemsList.appendChild(deleteAllButton);
        }
        //Chức năng xóa toàn  bộ sản phẩm trong giỏ hàng
        function deleteAllItems() {
            cartItems = [];
        }
        // Chức năng cập nhật tổng giá
        function updateTotalPrice() {
            let totalPriceElement = document.getElementById('totalPrice');
            let total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
            totalPriceElement.textContent = `Tổng tiền: ${total} VND`;
        }
        buttonsDiv.appendChild(Btn);
        newItem.appendChild(buttonsDiv);
        list.appendChild(newItem);
        
    });
}
function updateCartQuantity(change) {
    var quantitySpan = document.querySelector('.quantity');
    var currentQuantity = parseInt(quantitySpan.dataset.quantity);
    var newQuantity = currentQuantity + change;
    if (newQuantity >= 1) {
        quantitySpan.dataset.quantity = newQuantity;
        quantitySpan.textContent = newQuantity;
        // Gọi phương thức cập nhật số lượng trong giỏ hàng của bạn
        var productId = 1; // Thay bằng ID sản phẩm thích hợp
        cart.updateItemQuantity(productId, newQuantity);
    }
}

filter.addEventListener('submit', function (event) {
    event.preventDefault();
    let valueFilter = event.target.elements;
    productFilter = listProducts.filter(item => {
        // check category
        if (valueFilter.category.value != '') {
            if (item.nature.type != valueFilter.category.value) {
                return false;
            }
        }
        // check color
        if (valueFilter.color.value != '') {
            if (!item.nature.color.includes(valueFilter.color.value)) {
                return false;
            }
        }
        // check name
        if (valueFilter.name.value != '') {
            if (!item.name.includes(valueFilter.name.value)) {
                return false;
            }
        }
        // check min price
        if (valueFilter.minPrice.value != '') {
            if (item.price < valueFilter.minPrice.value) {
                return false;
            }
        }
        //  check max price
        if (valueFilter.maxPrice.value != '') {
            if (item.price > valueFilter.maxPrice.value) {
                return false;
            }
        }
        return true;
    })
    showProduct(productFilter);
})